[UI fixture placeholder prompt] Draw a background grid and one outline.
