[UI fixture placeholder prompt] Change the point colour.
