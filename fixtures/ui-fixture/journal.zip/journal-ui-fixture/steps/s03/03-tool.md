ReferenceError: pointColour is not defined
    at eval (eval at <anonymous> (about:srcdoc:27:16), <anonymous>:20:38)
    at eval (eval at <anonymous> (about:srcdoc:27:16), <anonymous>:22:3)
    at about:srcdoc:37:47
