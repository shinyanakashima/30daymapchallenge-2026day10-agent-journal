Summary (en): Point colour changed.
Summary (ja): 点の色を変更。

[UI fixture placeholder reply] Changed the colour (this code has a deliberate error).

```js
svg.append('rect').attr('width', width).attr('height', height).attr('fill', '#eef1ee');
const grid = svg.append('g').attr('stroke', '#d6dbd6');
for (let x = 0; x <= width; x += 100) grid.append('line').attr('x1', x).attr('x2', x).attr('y2', height);
for (let y = 0; y <= height; y += 100) grid.append('line').attr('y1', y).attr('y2', y).attr('x2', width);
const pts = d3.range(36).map(i => {
  const a = (i / 36) * Math.PI * 2;
  const r = 300 + 40 * Math.sin(a * 3) + 25 * Math.cos(a * 5);
  return [600 + r * Math.cos(a) * 1.25, 450 + r * Math.sin(a) * 0.95];
});
svg.append('polygon').attr('points', pts.join(' ')).attr('fill', '#e3e6dc').attr('stroke', '#5a6b4f').attr('stroke-width', 2);
svg.append('text').attr('x', 24).attr('y', 40).attr('font-family', 'sans-serif').attr('font-size', 14).text('UI FIXTURE · synthetic shapes · not real data');
const rows = data['data/points.csv'];
svg.append('g').selectAll('circle').data(rows).join('circle')
  .attr('cx', d => d.x).attr('cy', d => d.y).attr('r', d => d.value)
  .attr('fill', '#3a6ea5').attr('fill-opacity', 0.8).attr('stroke', '#fff').attr('stroke-width', 1.5);
svg.selectAll('circle').attr('fill', pointColour);
```
