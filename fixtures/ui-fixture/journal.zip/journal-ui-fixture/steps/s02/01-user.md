[UI fixture placeholder prompt] Add the points from data/points.csv, sized by value.
