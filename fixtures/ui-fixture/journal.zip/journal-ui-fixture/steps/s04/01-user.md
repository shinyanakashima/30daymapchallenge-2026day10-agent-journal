[UI fixture placeholder prompt] Fix the error, then add a title and a legend.
