svg.append('rect').attr('width', width).attr('height', height).attr('fill', '#eef1ee');
const grid = svg.append('g').attr('stroke', '#d6dbd6');
for (let x = 0; x <= width; x += 100) grid.append('line').attr('x1', x).attr('x2', x).attr('y2', height);
for (let y = 0; y <= height; y += 100) grid.append('line').attr('y1', y).attr('y2', y).attr('x2', width);
const pts = d3.range(36).map(i => {
  const a = (i / 36) * Math.PI * 2;
  const r = 300 + 40 * Math.sin(a * 3) + 25 * Math.cos(a * 5);
  return [600 + r * Math.cos(a) * 1.25, 450 + r * Math.sin(a) * 0.95];
});
svg.append('polygon').attr('points', pts.join(' ')).attr('fill', '#d9e4c8').attr('stroke', '#5a6b4f').attr('stroke-width', 2);
svg.append('text').attr('x', 24).attr('y', 40).attr('font-family', 'sans-serif').attr('font-size', 14).text('UI FIXTURE · synthetic shapes · not real data');
const rows = data['data/points.csv'];
svg.append('g').selectAll('circle').data(rows).join('circle')
  .attr('cx', d => d.x).attr('cy', d => d.y).attr('r', d => d.value)
  .attr('fill', '#c4512d').attr('fill-opacity', 0.8).attr('stroke', '#fff').attr('stroke-width', 1.5);
svg.append('text').attr('x', 24).attr('y', 860).attr('font-family', 'sans-serif').attr('font-size', 30).attr('font-weight', 700).text('Fixture frame · title and legend');
const lg = svg.append('g').attr('transform', 'translate(1000,830)');
lg.append('rect').attr('width', 170).attr('height', 40).attr('fill', '#fff').attr('stroke', '#bbb');
lg.append('circle').attr('cx', 20).attr('cy', 20).attr('r', 7).attr('fill', '#c4512d');
lg.append('text').attr('x', 36).attr('y', 25).attr('font-family', 'sans-serif').attr('font-size', 15).text('synthetic points');
