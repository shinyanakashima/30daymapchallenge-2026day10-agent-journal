# UI fixture (not the production session)

Map Rewind journal. One commit per step: prompts, responses, map code and screen captures.
